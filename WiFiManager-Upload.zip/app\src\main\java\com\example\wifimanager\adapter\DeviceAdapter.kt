package com.example.wifimanager.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView
import com.example.wifimanager.R
import com.example.wifimanager.model.NetworkDevice
import com.example.wifimanager.model.DeviceType

class DeviceAdapter(
    private val onBlockClick: (NetworkDevice) -> Unit,
    private val onLimitClick: (NetworkDevice) -> Unit
) : RecyclerView.Adapter<DeviceAdapter.DeviceViewHolder>() {

    private var devices: List<NetworkDevice> = emptyList()

    fun updateDevices(newDevices: List<NetworkDevice>) {
        devices = newDevices
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DeviceViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_device, parent, false)
        return DeviceViewHolder(view)
    }

    override fun onBindViewHolder(holder: DeviceViewHolder, position: Int) {
        holder.bind(devices[position])
    }

    override fun getItemCount(): Int = devices.size

    inner class DeviceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val deviceIcon: ImageView = itemView.findViewById(R.id.iv_device_icon)
        private val deviceName: TextView = itemView.findViewById(R.id.tv_device_name)
        private val deviceInfo: TextView = itemView.findViewById(R.id.tv_device_info)
        private val deviceStatus: TextView = itemView.findViewById(R.id.tv_device_status)
        private val deviceSpeed: TextView = itemView.findViewById(R.id.tv_device_speed)
        private val blockButton: Button = itemView.findViewById(R.id.btn_block)
        private val limitButton: Button = itemView.findViewById(R.id.btn_limit)

        fun bind(device: NetworkDevice) {
            // Cihaz ikonu
            deviceIcon.setImageResource(getDeviceIcon(device.deviceType))
            
            // Cihaz adı
            deviceName.text = if (device.hostname != "Bilinmeyen") {
                device.hostname
            } else {
                device.manufacturer.takeIf { it != "Bilinmeyen" } ?: "Bilinmeyen Cihaz"
            }
            
            // Cihaz bilgileri
            deviceInfo.text = "IP: ${device.ipAddress}\nMAC: ${device.macAddress}"
            
            // Cihaz durumu
            deviceStatus.text = when {
                device.isBlocked -> "🚫 Engellenmiş"
                device.isOnline -> "🟢 Online"
                else -> "🔴 Offline"
            }
            
            // Hız bilgisi
            deviceSpeed.text = if (device.downloadSpeed > 0 || device.uploadSpeed > 0) {
                "⬇️ ${formatSpeed(device.downloadSpeed)} ⬆️ ${formatSpeed(device.uploadSpeed)}"
            } else {
                "Hız bilgisi yok"
            }
            
            // Butonlar
            blockButton.text = if (device.isBlocked) "Engeli Kaldır" else "Engelle"
            blockButton.setOnClickListener { onBlockClick(device) }
            
            limitButton.setOnClickListener { onLimitClick(device) }
            
            // Offline cihazlar için butonları devre dışı bırak
            val isEnabled = device.isOnline
            blockButton.isEnabled = isEnabled
            limitButton.isEnabled = isEnabled
            
            // Renk ayarları
            itemView.setBackgroundColor(
                when {
                    device.isBlocked -> 0xFFFFEBEE.toInt()
                    device.isOnline -> 0xFFE8F5E8.toInt()
                    else -> 0xFFF5F5F5.toInt()
                }
            )
        }
        
        private fun getDeviceIcon(deviceType: DeviceType): Int {
            return when (deviceType) {
                DeviceType.PHONE -> R.drawable.ic_phone
                DeviceType.TABLET -> R.drawable.ic_tablet
                DeviceType.LAPTOP -> R.drawable.ic_laptop
                DeviceType.DESKTOP -> R.drawable.ic_desktop
                DeviceType.SMART_TV -> R.drawable.ic_tv
                DeviceType.GAME_CONSOLE -> R.drawable.ic_gamepad
                DeviceType.ROUTER -> R.drawable.ic_router
                DeviceType.PRINTER -> R.drawable.ic_printer
                DeviceType.UNKNOWN -> R.drawable.ic_device_unknown
            }
        }
        
        private fun formatSpeed(speedKbs: Long): String {
            return when {
                speedKbs >= 1024 -> String.format("%.1f MB/s", speedKbs / 1024.0)
                speedKbs > 0 -> "${speedKbs} KB/s"
                else -> "0 KB/s"
            }
        }
    }
}
