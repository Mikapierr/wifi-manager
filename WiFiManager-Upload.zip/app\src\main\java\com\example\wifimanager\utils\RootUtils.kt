package com.example.wifimanager.utils

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.IOException
import java.io.InputStreamReader

object RootUtils {
    private const val TAG = "RootUtils"
    
    fun checkRootAccess(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec("su")
            val os = DataOutputStream(process.outputStream)
            os.writeBytes("exit\n")
            os.flush()
            process.waitFor()
            process.exitValue() == 0
        } catch (e: Exception) {
            Log.e(TAG, "Root kontrol hatası: ${e.message}")
            false
        }
    }
    
    suspend fun executeRootCommand(command: String): String = withContext(Dispatchers.IO) {
        val result = StringBuilder()
        
        try {
            val process = Runtime.getRuntime().exec("su")
            val os = DataOutputStream(process.outputStream)
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            
            os.writeBytes("$command\n")
            os.writeBytes("exit\n")
            os.flush()
            
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                result.append(line).append("\n")
            }
            
            process.waitFor()
            reader.close()
            os.close()
            
        } catch (e: Exception) {
            Log.e(TAG, "Root komut çalıştırma hatası: ${e.message}")
            return@withContext "Hata: ${e.message}"
        }
        
        return@withContext result.toString()
    }
    
    suspend fun scanNetwork(): List<String> = withContext(Dispatchers.IO) {
        val devices = mutableListOf<String>()
        
        try {
            // ARP tablosunu kontrol et
            val arpResult = executeRootCommand("cat /proc/net/arp")
            
            arpResult.lines().forEach { line ->
                if (line.contains("0x2")) { // Aktif cihazlar
                    val parts = line.split("\\s+".toRegex())
                    if (parts.size >= 4) {
                        val ip = parts[0]
                        val mac = parts[3]
                        devices.add("$ip,$mac")
                    }
                }
            }
            
            // Nmap ile tarama (eğer yüklüyse)
            val gateway = getGateway()
            if (gateway.isNotEmpty()) {
                val networkBase = gateway.substringBeforeLast(".") + ".0/24"
                val nmapResult = executeRootCommand("nmap -sn $networkBase")
                
                // Nmap sonuçlarını işle
                // Bu kısım daha karmaşık parsing gerektirir
            }
            
        } catch (e: Exception) {
            Log.e(TAG, "Ağ tarama hatası: ${e.message}")
        }
        
        return@withContext devices
    }
    
    suspend fun blockDevice(ipAddress: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val command = "iptables -I FORWARD -s $ipAddress -j DROP"
            val result = executeRootCommand(command)
            return@withContext !result.contains("error", ignoreCase = true)
        } catch (e: Exception) {
            Log.e(TAG, "Cihaz engelleme hatası: ${e.message}")
            return@withContext false
        }
    }
    
    suspend fun unblockDevice(ipAddress: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val command = "iptables -D FORWARD -s $ipAddress -j DROP"
            val result = executeRootCommand(command)
            return@withContext !result.contains("error", ignoreCase = true)
        } catch (e: Exception) {
            Log.e(TAG, "Cihaz engel kaldırma hatası: ${e.message}")
            return@withContext false
        }
    }
    
    suspend fun limitBandwidth(ipAddress: String, downloadLimit: Int, uploadLimit: Int): Boolean = withContext(Dispatchers.IO) {
        try {
            // TC (traffic control) kullanarak bandwidth sınırlandırma
            val commands = listOf(
                "tc qdisc add dev wlan0 root handle 1: htb default 30",
                "tc class add dev wlan0 parent 1: classid 1:1 htb rate ${downloadLimit}kbit ceil ${downloadLimit}kbit",
                "tc filter add dev wlan0 parent 1: protocol ip prio 1 u32 match ip dst $ipAddress flowid 1:1"
            )
            
            commands.forEach { command ->
                val result = executeRootCommand(command)
                if (result.contains("error", ignoreCase = true)) {
                    return@withContext false
                }
            }
            
            return@withContext true
        } catch (e: Exception) {
            Log.e(TAG, "Bandwidth sınırlandırma hatası: ${e.message}")
            return@withContext false
        }
    }
    
    private suspend fun getGateway(): String = withContext(Dispatchers.IO) {
        try {
            val result = executeRootCommand("ip route show default")
            val lines = result.lines()
            for (line in lines) {
                if (line.contains("default via")) {
                    val parts = line.split(" ")
                    val index = parts.indexOf("via")
                    if (index != -1 && index + 1 < parts.size) {
                        return@withContext parts[index + 1]
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Gateway alma hatası: ${e.message}")
        }
        return@withContext ""
    }
}
