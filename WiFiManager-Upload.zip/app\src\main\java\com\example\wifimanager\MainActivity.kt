package com.example.wifimanager

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.wifimanager.adapter.DeviceAdapter
import com.example.wifimanager.databinding.ActivityMainBinding
import com.example.wifimanager.manager.NetworkManager
import com.example.wifimanager.model.NetworkDevice
import com.example.wifimanager.utils.RootUtils
import com.scottyab.rootbeer.RootBeer
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private lateinit var networkManager: NetworkManager
    private lateinit var deviceAdapter: DeviceAdapter
    private var rootBeer: RootBeer? = null
    
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.all { it.value }
        if (allGranted) {
            initializeNetwork()
        } else {
            Toast.makeText(this, "İzinler gerekli!", Toast.LENGTH_LONG).show()
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        checkRootAndPermissions()
        setupUI()
    }
    
    private fun checkRootAndPermissions() {
        rootBeer = RootBeer(this)
        
        if (!rootBeer!!.isRooted) {
            AlertDialog.Builder(this)
                .setTitle("Root Gerekli")
                .setMessage("Bu uygulama root yetkilerine ihtiyaç duyar. Lütfen cihazınızı root yapın.")
                .setPositiveButton("Tamam") { _, _ -> finish() }
                .setCancelable(false)
                .show()
            return
        }
        
        // Root kontrolü
        if (!RootUtils.checkRootAccess()) {
            AlertDialog.Builder(this)
                .setTitle("Root Erişimi")
                .setMessage("Root erişimi sağlanamadı. Lütfen uygulamaya root izni verin.")
                .setPositiveButton("Tamam") { _, _ -> finish() }
                .setCancelable(false)
                .show()
            return
        }
        
        requestPermissions()
    }
    
    private fun requestPermissions() {
        val permissions = arrayOf(
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.CHANGE_WIFI_STATE,
            Manifest.permission.ACCESS_NETWORK_STATE,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        
        val needsPermission = permissions.any {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        
        if (needsPermission) {
            permissionLauncher.launch(permissions)
        } else {
            initializeNetwork()
        }
    }
    
    private fun setupUI() {
        // Toolbar
        setSupportActionBar(binding.toolbar)
        
        // RecyclerView
        deviceAdapter = DeviceAdapter(
            onBlockClick = { device -> handleBlockDevice(device) },
            onLimitClick = { device -> showBandwidthDialog(device) }
        )
        
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = deviceAdapter
        }
        
        // Butonlar
        binding.fabScan.setOnClickListener {
            scanForDevices()
        }
        
        binding.btnRefresh.setOnClickListener {
            scanForDevices()
        }
    }
    
    private fun initializeNetwork() {
        networkManager = NetworkManager(this)
        
        // WiFi durumu kontrolü
        updateWifiStatus()
        
        // Cihaz listesi gözlemle
        lifecycleScope.launch {
            networkManager.devices.collect { devices ->
                deviceAdapter.updateDevices(devices)
                updateStats(devices)
            }
        }
        
        // Tarama durumu gözlemle
        lifecycleScope.launch {
            networkManager.isScanning.collect { isScanning ->
                binding.fabScan.isEnabled = !isScanning
                binding.btnRefresh.isEnabled = !isScanning
                
                if (isScanning) {
                    binding.tvStatus.text = "Cihazlar taranıyor..."
                } else {
                    binding.tvStatus.text = "Tarama tamamlandı"
                }
            }
        }
        
        // İlk tarama
        scanForDevices()
    }
    
    private fun updateWifiStatus() {
        val wifiName = networkManager.getConnectedWifiName()
        val isWifiEnabled = networkManager.isWifiEnabled()
        
        binding.tvWifiName.text = if (isWifiEnabled && wifiName != null) {
            "Bağlı: $wifiName"
        } else {
            "WiFi bağlantısı yok"
        }
    }
    
    private fun updateStats(devices: List<NetworkDevice>) {
        val totalDevices = devices.size
        val onlineDevices = devices.count { it.isOnline }
        val blockedDevices = devices.count { it.isBlocked }
        
        binding.tvDeviceCount.text = "Toplam: $totalDevices"
        binding.tvOnlineCount.text = "Online: $onlineDevices"
        binding.tvBlockedCount.text = "Engellenmiş: $blockedDevices"
    }
    
    private fun scanForDevices() {
        lifecycleScope.launch {
            try {
                networkManager.scanForDevices()
                updateWifiStatus()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Tarama hatası: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun handleBlockDevice(device: NetworkDevice) {
        lifecycleScope.launch {
            try {
                val success = if (device.isBlocked) {
                    networkManager.unblockDevice(device)
                } else {
                    networkManager.blockDevice(device)
                }
                
                if (success) {
                    val action = if (device.isBlocked) "engeli kaldırıldı" else "engellendi"
                    Toast.makeText(this@MainActivity, "${device.hostname} $action", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, "İşlem başarısız", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Hata: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun showBandwidthDialog(device: NetworkDevice) {
        val options = arrayOf(
            "Sınırsız",
            "1 Mbps",
            "2 Mbps",
            "5 Mbps",
            "10 Mbps",
            "Özel..."
        )
        
        AlertDialog.Builder(this)
            .setTitle("${device.hostname} - Hız Sınırı")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> removeBandwidthLimit(device)
                    1 -> setBandwidthLimit(device, 1024, 1024)
                    2 -> setBandwidthLimit(device, 2048, 2048)
                    3 -> setBandwidthLimit(device, 5120, 5120)
                    4 -> setBandwidthLimit(device, 10240, 10240)
                    5 -> showCustomBandwidthDialog(device)
                }
            }
            .show()
    }
    
    private fun showCustomBandwidthDialog(device: NetworkDevice) {
        // Özel hız sınırı dialog'u - basit implementasyon
        AlertDialog.Builder(this)
            .setTitle("Özel Hız Sınırı")
            .setMessage("Bu özellik geliştirilme aşamasında...")
            .setPositiveButton("Tamam", null)
            .show()
    }
    
    private fun setBandwidthLimit(device: NetworkDevice, downloadLimit: Int, uploadLimit: Int) {
        lifecycleScope.launch {
            try {
                val success = networkManager.limitDeviceBandwidth(device, downloadLimit, uploadLimit)
                if (success) {
                    Toast.makeText(this@MainActivity, "Hız sınırı uygulandı", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, "Hız sınırı uygulanamadı", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Hata: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun removeBandwidthLimit(device: NetworkDevice) {
        // Hız sınırını kaldır
        Toast.makeText(this, "Hız sınırı kaldırıldı", Toast.LENGTH_SHORT).show()
    }
}
