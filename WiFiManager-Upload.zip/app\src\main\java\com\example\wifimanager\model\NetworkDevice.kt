package com.example.wifimanager.model

data class NetworkDevice(
    val ipAddress: String,
    val macAddress: String,
    val hostname: String = "Bilinmeyen",
    val manufacturer: String = "Bilinmeyen",
    val isOnline: Boolean = false,
    val isBlocked: Boolean = false,
    val downloadSpeed: Long = 0, // KB/s
    val uploadSpeed: Long = 0, // KB/s
    val totalDownload: Long = 0, // MB
    val totalUpload: Long = 0, // MB
    val deviceType: DeviceType = DeviceType.UNKNOWN
)

enum class DeviceType {
    PHONE,
    TABLET,
    LAPTOP,
    DESKTOP,
    SMART_TV,
    GAME_CONSOLE,
    ROUTER,
    PRINTER,
    UNKNOWN
}

data class NetworkStats(
    val totalDevices: Int,
    val onlineDevices: Int,
    val blockedDevices: Int,
    val totalBandwidth: Long // KB/s
)
