package com.example.wifimanager.manager

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import com.example.wifimanager.model.NetworkDevice
import com.example.wifimanager.model.DeviceType
import com.example.wifimanager.utils.RootUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap

class NetworkManager(private val context: Context) {
    private val TAG = "NetworkManager"
    
    private val _devices = MutableStateFlow<List<NetworkDevice>>(emptyList())
    val devices: StateFlow<List<NetworkDevice>> = _devices.asStateFlow()
    
    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()
    
    private val _networkStats = MutableStateFlow<Map<String, Long>>(emptyMap())
    val networkStats: StateFlow<Map<String, Long>> = _networkStats.asStateFlow()
    
    private val deviceCache = ConcurrentHashMap<String, NetworkDevice>()
    private val blockedDevices = mutableSetOf<String>()
    
    private val wifiManager = context.getSystemService(Context.WIFI_SERVICE) as WifiManager
    
    suspend fun scanForDevices() = withContext(Dispatchers.IO) {
        _isScanning.value = true
        val foundDevices = mutableListOf<NetworkDevice>()
        
        try {
            // Root ile ağ tarama
            val rawDevices = RootUtils.scanNetwork()
            
            for (deviceInfo in rawDevices) {
                val parts = deviceInfo.split(",")
                if (parts.size >= 2) {
                    val ip = parts[0]
                    val mac = parts[1]
                    
                    val device = createOrUpdateDevice(ip, mac)
                    foundDevices.add(device)
                }
            }
            
            // Ping ile cihazların online durumunu kontrol et
            foundDevices.forEach { device ->
                val isOnline = pingDevice(device.ipAddress)
                val updatedDevice = device.copy(isOnline = isOnline)
                deviceCache[device.ipAddress] = updatedDevice
            }
            
            _devices.value = deviceCache.values.toList()
            
        } catch (e: Exception) {
            Log.e(TAG, "Cihaz tarama hatası: ${e.message}")
        } finally {
            _isScanning.value = false
        }
    }
    
    private suspend fun createOrUpdateDevice(ip: String, mac: String): NetworkDevice {
        val existingDevice = deviceCache[ip]
        
        return if (existingDevice != null) {
            // Mevcut cihazı güncelle
            existingDevice.copy(
                macAddress = mac,
                isBlocked = blockedDevices.contains(ip)
            )
        } else {
            // Yeni cihaz oluştur
            val hostname = getHostname(ip)
            val manufacturer = getMacManufacturer(mac)
            val deviceType = guessDeviceType(hostname, manufacturer)
            
            NetworkDevice(
                ipAddress = ip,
                macAddress = mac,
                hostname = hostname,
                manufacturer = manufacturer,
                deviceType = deviceType,
                isBlocked = blockedDevices.contains(ip)
            )
        }
    }
    
    private suspend fun pingDevice(ip: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val address = InetAddress.getByName(ip)
            return@withContext address.isReachable(3000) // 3 saniye timeout
        } catch (e: Exception) {
            return@withContext false
        }
    }
    
    private suspend fun getHostname(ip: String): String = withContext(Dispatchers.IO) {
        try {
            val address = InetAddress.getByName(ip)
            return@withContext address.hostName ?: "Bilinmeyen"
        } catch (e: Exception) {
            return@withContext "Bilinmeyen"
        }
    }
    
    private fun getMacManufacturer(mac: String): String {
        // MAC adresi OUI (Organizationally Unique Identifier) lookup
        val oui = mac.substring(0, 8).uppercase()
        
        val manufacturers = mapOf(
            "00:1B:63" to "Apple",
            "00:23:12" to "Apple",
            "00:26:08" to "Apple",
            "3C:15:C2" to "Apple",
            "A4:5E:60" to "Apple",
            "B8:E8:56" to "Apple",
            "00:50:56" to "VMware",
            "00:0C:29" to "VMware",
            "00:05:69" to "VMware",
            "08:00:27" to "Oracle VirtualBox",
            "00:16:3E" to "Xen",
            "00:15:5D" to "Microsoft",
            "00:1C:42" to "Parallels",
            "00:03:FF" to "Microsoft",
            "00:12:F0" to "Microsoft",
            "28:18:78" to "Samsung",
            "00:12:EE" to "Samsung",
            "00:16:32" to "Samsung",
            "00:21:19" to "Samsung",
            "00:23:39" to "Samsung",
            "00:26:37" to "Samsung",
            "90:18:7C" to "LG Electronics",
            "00:1F:6B" to "LG Electronics",
            "00:09:DF" to "LG Electronics"
        )
        
        return manufacturers[oui] ?: "Bilinmeyen"
    }
    
    private fun guessDeviceType(hostname: String, manufacturer: String): DeviceType {
        val hostnameLower = hostname.lowercase()
        val manufacturerLower = manufacturer.lowercase()
        
        return when {
            hostnameLower.contains("iphone") || hostnameLower.contains("android") -> DeviceType.PHONE
            hostnameLower.contains("ipad") || hostnameLower.contains("tablet") -> DeviceType.TABLET
            hostnameLower.contains("macbook") || hostnameLower.contains("laptop") -> DeviceType.LAPTOP
            hostnameLower.contains("desktop") || hostnameLower.contains("pc") -> DeviceType.DESKTOP
            hostnameLower.contains("tv") || hostnameLower.contains("smart") -> DeviceType.SMART_TV
            hostnameLower.contains("xbox") || hostnameLower.contains("playstation") -> DeviceType.GAME_CONSOLE
            hostnameLower.contains("router") || hostnameLower.contains("gateway") -> DeviceType.ROUTER
            hostnameLower.contains("printer") -> DeviceType.PRINTER
            manufacturerLower.contains("apple") -> DeviceType.PHONE // Default for Apple devices
            manufacturerLower.contains("samsung") -> DeviceType.PHONE // Default for Samsung devices
            else -> DeviceType.UNKNOWN
        }
    }
    
    suspend fun blockDevice(device: NetworkDevice): Boolean {
        val success = RootUtils.blockDevice(device.ipAddress)
        if (success) {
            blockedDevices.add(device.ipAddress)
            updateDeviceInCache(device.copy(isBlocked = true))
        }
        return success
    }
    
    suspend fun unblockDevice(device: NetworkDevice): Boolean {
        val success = RootUtils.unblockDevice(device.ipAddress)
        if (success) {
            blockedDevices.remove(device.ipAddress)
            updateDeviceInCache(device.copy(isBlocked = false))
        }
        return success
    }
    
    suspend fun limitDeviceBandwidth(device: NetworkDevice, downloadLimit: Int, uploadLimit: Int): Boolean {
        return RootUtils.limitBandwidth(device.ipAddress, downloadLimit, uploadLimit)
    }
    
    private fun updateDeviceInCache(device: NetworkDevice) {
        deviceCache[device.ipAddress] = device
        _devices.value = deviceCache.values.toList()
    }
    
    fun getConnectedWifiName(): String? {
        return try {
            val wifiInfo = wifiManager.connectionInfo
            wifiInfo?.ssid?.replace("\"", "")
        } catch (e: Exception) {
            null
        }
    }
    
    fun isWifiEnabled(): Boolean {
        return wifiManager.isWifiEnabled
    }
    
    fun getDeviceCount(): Int = _devices.value.size
    fun getOnlineDeviceCount(): Int = _devices.value.count { it.isOnline }
    fun getBlockedDeviceCount(): Int = _devices.value.count { it.isBlocked }
}
